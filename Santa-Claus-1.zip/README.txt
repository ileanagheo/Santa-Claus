Gheorghisor Ileana-Teodora, 323 CA

Etapa 1 - Proiect POO

Din pacate nu am reusit sa termin tema, insa sunt pe drumul cel bun si sper sa
o termin pentru etapa a doua. Nu mai am timp sa scriu ce am facut in ea si nici
nu cred ca are rost din moment ce nu am niciun punctaj pe teste.
Am lasat pe parcurs comentarii care sa ma ajute sa inteleg pas cu pas ce am
facut.